# BTC 盘口滑点估算工具

端到端工具:从抓取 Binance 实时深度开始,在**静态盘口**上模拟一笔大额市价单逐档成交,
输出成交均价(VWAP)与最后一口价格相对盘口最优价的 bp 差。

## 文件

- `estimate_slippage.py` —— 主程序,仅依赖 Python 3.8+ 标准库,免 API key。

## 用法

```bash
# 卖出 1500 万美元等值的 BTC,看相对买一滑几个 bp
python estimate_slippage.py --symbol BTCUSDT --side sell --notional 15000000

# 买入 10 个 BTC
python estimate_slippage.py --symbol BTCUSDT --side buy --qty 10

# 换交易对 / 减少深度档数
python estimate_slippage.py --symbol ETHUSDT --side sell --notional 5000000 --limit 1000

# 复算截图里那 33 档买盘的总额(不抓盘口)
python estimate_slippage.py --demo-screenshot

# 输出 JSON,方便二次处理
python estimate_slippage.py --symbol BTCUSDT --side sell --notional 15000000 --json
```

## 输出示例

```
交易对: BTCUSDT  方向: SELL  目标: $15,000,000.00
盘口最优价(top): 85,962.76   同侧盘口总额: $18,771,651 (5000 档)
吃掉档位数: 2437
实际成交: 174.7821 / $15,000,000.00
VWAP: 85,821.14      → 相对 top 差 16.5 bp
最后一口: 85,631.60  → 相对 top 差 38.5 bp
注意: 静态盘口估算, 未含手续费; 真实大额成交时盘口会动态变化, 实际滑点通常更大
```

## 验证记录 (2026-10-05)

1. 截图 33 档买盘用 `Decimal` 独立复核:**3.44714 BTC = $296,629.23**,与手工加总一致。
2. 1500 万美元市价卖单用**两种不同写法**各拉一次新鲜盘口重算,逻辑自洽
   (数字随盘口实时浮动,属正常现象)。

## 注意事项

- 这是**静态**估算:真实砸盘时做市商/HFT 会撤单,实际滑点通常更大。
- 未计 taker 手续费(现货约 0.1% = 10bp)。
- 若目标金额超出 5000 档盘口总额,程序会明确报错而不是给出错误数字。
