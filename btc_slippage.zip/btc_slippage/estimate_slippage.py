#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
estimate_slippage.py
====================
币安现货「静态盘口」滑点估算工具: 端到端从抓取实时深度开始,
模拟一笔大额市价单在当前盘口上逐档成交, 输出:
  - 成交均价 (VWAP) 与最后一口成交价
  - 两者相对盘口最优价 (top bid/ask) 的 bp 差

数据来源: Binance 公开行情接口 data-api.binance.vision (免 API key, 仅行情)
盘口上限: limit=5000 档; 若目标金额超出盘口总额会明确报错。

依赖: 仅 Python 3.8+ 标准库。

示例:
    # 卖出 1500 万美元等值的 BTC, 看相对买一滑几个 bp
    python estimate_slippage.py --symbol BTCUSDT --side sell --notional 15000000

    # 买入 10 个 BTC
    python estimate_slippage.py --symbol BTCUSDT --side buy --qty 10

    # 复算 README 里那张截图的 33 档买盘总额
    python estimate_slippage.py --demo-screenshot

    # 输出 JSON, 方便二次处理
    python estimate_slippage.py --symbol BTCUSDT --side sell --notional 15000000 --json
"""

import argparse
import json
import sys
import urllib.request

API_BASE = "https://data-api.binance.vision"
MAX_LIMIT = 5000

# 2026-10-05 BTC/USDT 买盘截图(从上到下): (数量, 价格)
SCREENSHOT_BIDS = [
    (1.23548, 86055.48), (0.00066, 86055.47), (0.00014, 86054.55),
    (0.03618, 86054.54), (0.11866, 86054.53), (0.00007, 86054.29),
    (0.00006, 86053.75), (0.00009, 86053.00), (0.00599, 86052.98),
    (0.00012, 86052.00), (0.00999, 86051.60), (0.00007, 86051.35),
    (0.00006, 86051.06), (0.00014, 86050.90), (0.10734, 86050.89),
    (0.01199, 86050.22), (0.00006, 86050.00), (0.00006, 86049.49),
    (0.00006, 86049.46), (0.01199, 86048.84), (0.00047, 86048.77),
    (0.00020, 86048.54), (0.31393, 86048.53), (0.00007, 86048.49),
    (0.03496, 86048.48), (0.03486, 86048.47), (0.00069, 86048.43),
    (0.00160, 86048.27), (0.00012, 86047.74), (0.00550, 86047.60),
    (0.00400, 86047.26), (0.50363, 86047.25), (1.00790, 86047.24),
]


def fetch_depth(symbol, limit=5000, timeout=25):
    """抓取 Binance 现货深度。返回 (bids, asks), 元素为 (price, qty) float 元组。"""
    if not 1 <= limit <= MAX_LIMIT:
        raise ValueError(f"limit 须在 1~{MAX_LIMIT} 之间")
    url = f"{API_BASE}/api/v3/depth?symbol={symbol.upper()}&limit={limit}"
    req = urllib.request.Request(url, headers={"User-Agent": "slippage-tool/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.load(resp)
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(f"抓取深度失败 ({url}): {e}") from e
    if "bids" not in data or "asks" not in data:
        raise RuntimeError(f"深度接口返回异常: {str(data)[:200]}")
    bids = [(float(p), float(q)) for p, q in data["bids"]]  # 价格从高到低
    asks = [(float(p), float(q)) for p, q in data["asks"]]  # 价格从低到高
    if not bids or not asks:
        raise RuntimeError("盘口为空, 无法估算")
    return bids, asks


def walk_book(levels, target_usd=None, target_qty=None):
    """在静态盘口上逐档吃单。

    levels: [(price, qty)] 从最优到最差。
    target_usd / target_qty 二选一。
    返回 dict: filled_qty, cost_usd, vwap, last_price, levels_used。
    深度不足时抛 RuntimeError。
    """
    if (target_usd is None) == (target_qty is None):
        raise ValueError("target_usd 与 target_qty 必须且只能指定一个")
    filled_qty, cost, last_price, used = 0.0, 0.0, None, 0
    for price, qty in levels:
        if price <= 0 or qty <= 0:
            continue
        if target_qty is not None:
            take = min(qty, target_qty - filled_qty)
        else:
            take = min(qty, (target_usd - cost) / price)
        if take <= 0:
            break
        filled_qty += take
        cost += take * price
        last_price = price
        used += 1
        done = (target_qty is not None and filled_qty >= target_qty) or \
               (target_usd is not None and cost >= target_usd)
        if done:
            break
    want = target_qty if target_qty is not None else target_usd
    got = filled_qty if target_qty is not None else cost
    if got < want * (1 - 1e-9):
        unit = "qty" if target_qty is not None else "USD"
        raise RuntimeError(
            f"盘口深度不足: 目标 {want:,.4f} {unit} 只吃到 {got:,.4f} (已用 {used} 档)")
    return {
        "filled_qty": filled_qty,
        "cost_usd": cost,
        "vwap": cost / filled_qty,
        "last_price": last_price,
        "levels_used": used,
    }


def book_total_usd(levels):
    return sum(p * q for p, q in levels)


def bp_diff(ref_price, price):
    """price 相对 ref_price 低了多少 bp(基点); 为负表示 price 更高。"""
    return (ref_price - price) / ref_price * 1e4


def demo_screenshot():
    qty = sum(q for q, _ in SCREENSHOT_BIDS)
    usd = sum(q * p for q, p in SCREENSHOT_BIDS)
    return {
        "levels": len(SCREENSHOT_BIDS),
        "total_qty": qty,
        "total_usd": usd,
        "avg_price": usd / qty,
        "top_bid": SCREENSHOT_BIDS[0][1],
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description="币安现货静态盘口滑点估算")
    ap.add_argument("--symbol", default="BTCUSDT", help="交易对, 默认 BTCUSDT")
    ap.add_argument("--side", choices=["sell", "buy"], default="sell",
                    help="sell=吃买盘(砸盘), buy=吃卖盘, 默认 sell")
    ap.add_argument("--notional", type=float, default=None,
                    help="目标名义金额(USD), 与 --qty 二选一")
    ap.add_argument("--qty", type=float, default=None,
                    help="目标数量(币本位), 与 --notional 二选一")
    ap.add_argument("--limit", type=int, default=5000, help="深度档数, 默认 5000")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--demo-screenshot", action="store_true",
                    help="仅复算截图里 33 档买盘的总额, 不抓盘口")
    args = ap.parse_args(argv)

    if args.demo_screenshot:
        r = demo_screenshot()
        if args.json:
            print(json.dumps(r, indent=2))
        else:
            print(f"截图买盘: {r['levels']} 档, {r['total_qty']:.5f} BTC, "
                  f"合计 ${r['total_usd']:,.2f}, 加权均价 {r['avg_price']:,.2f}")
        return 0

    if (args.notional is None) == (args.qty is None):
        ap.error("--notional 与 --qty 必须且只能指定一个")

    bids, asks = fetch_depth(args.symbol, limit=args.limit)
    levels = bids if args.side == "sell" else asks
    top = levels[0][0]

    try:
        r = walk_book(levels, target_usd=args.notional, target_qty=args.qty)
    except RuntimeError as e:
        print(f"估算失败: {e}", file=sys.stderr)
        return 1

    result = {
        "symbol": args.symbol.upper(),
        "side": args.side,
        "target_usd": args.notional,
        "target_qty": args.qty,
        "top_price": top,
        "book_side_total_usd": book_total_usd(levels),
        "book_levels": len(levels),
        **r,
        "vwap_vs_top_bp": bp_diff(top, r["vwap"]),
        "last_vs_top_bp": bp_diff(top, r["last_price"]),
        "note": "静态盘口估算, 未含手续费; 真实大额成交时盘口会动态变化, 实际滑点通常更大",
    }

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        target_txt = f"${args.notional:,.2f}" if args.notional else f"{args.qty} {args.symbol.upper()}"
        print(f"交易对: {result['symbol']}  方向: {args.side.upper()}  目标: {target_txt}")
        print(f"盘口最优价(top): {top:,.2f}   同侧盘口总额: ${result['book_side_total_usd']:,.0f} ({len(levels)} 档)")
        print(f"吃掉档位数: {r['levels_used']}")
        print(f"实际成交: {r['filled_qty']:.4f} / ${r['cost_usd']:,.2f}")
        print(f"VWAP: {r['vwap']:,.2f}      → 相对 top 差 {result['vwap_vs_top_bp']:.1f} bp")
        print(f"最后一口: {r['last_price']:,.2f}  → 相对 top 差 {result['last_vs_top_bp']:.1f} bp")
        print(f"注意: {result['note']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
